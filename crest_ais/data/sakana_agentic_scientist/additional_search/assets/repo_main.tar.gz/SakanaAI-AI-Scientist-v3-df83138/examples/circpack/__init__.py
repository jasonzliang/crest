"""Circle-packing example task."""

